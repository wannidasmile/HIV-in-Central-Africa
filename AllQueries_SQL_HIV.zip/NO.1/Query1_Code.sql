/*Joining two tables*/
SELECT *
FROM hiv_project.table1_final T1
JOIN hiv_project.table2_final T2
ON T1.Country = T2.Country 
AND T1.year = T2.year