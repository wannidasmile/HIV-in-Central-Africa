/* Compare Pregnant with HIV vs Transmission Rate*/
SELECT T1.Country, T1.Year ,SUM(T1.Percent_pregnant_with_HIV) AS Percent_Pregnant_with_HIV, 
sum(T1.MothertoChild_transmission_rate) AS Transmissioin_Rate
FROM hiv_project.table1_final T1 
WHERE T1.Country = "Chad"
GROUP BY T1.Country, T1.Year
LIMIT 0, 1000;